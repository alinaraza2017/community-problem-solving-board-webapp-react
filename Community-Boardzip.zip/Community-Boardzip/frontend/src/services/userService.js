import api from './api';

export const getProfile = () => api.get('/users/profile').then((r) => r.data);
export const getUserById = (id) => api.get(`/users/${id}`).then((r) => r.data);
export const updateProfile = (id, data) =>
  api.put(`/users/${id}`, data).then((r) => r.data);
export const getAllUsers = () => api.get('/users').then((r) => r.data);
