import api from './api';

export const getComments = (issueId) =>
  api.get(`/comments/${issueId}`).then((r) => r.data);

export const postComment = (data) =>
  api.post('/comments', data).then((r) => r.data);
