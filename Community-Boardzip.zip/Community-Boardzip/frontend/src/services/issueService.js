import api from './api';

export const getIssues = () => api.get('/issues').then((r) => r.data);
export const getIssue = (id) => api.get(`/issues/${id}`).then((r) => r.data);
export const createIssue = (data) => api.post('/issues', data).then((r) => r.data);
export const upvoteIssue = (id) => api.put(`/issues/upvote/${id}`).then((r) => r.data);
export const getPostedIssues = () => api.get('/issues/posted').then((r) => r.data);
export const getVotedIssues = () => api.get('/issues/voted').then((r) => r.data);
export const updateIssue = (id, data) => api.put(`/issues/${id}`, data).then((r) => r.data);
export const deleteIssue = (id) => api.delete(`/issues/${id}`).then((r) => r.data);
