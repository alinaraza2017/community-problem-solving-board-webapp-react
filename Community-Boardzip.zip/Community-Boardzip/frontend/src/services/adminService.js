import api from './api';

export const getAdminStats = () => api.get('/admin/stats').then((r) => r.data);
export const updateIssueStatus = (id, status) =>
  api.put(`/admin/issues/${id}/status`, { status }).then((r) => r.data);
export const deleteIssueAdmin = (id) =>
  api.delete(`/admin/issues/${id}`).then((r) => r.data);
