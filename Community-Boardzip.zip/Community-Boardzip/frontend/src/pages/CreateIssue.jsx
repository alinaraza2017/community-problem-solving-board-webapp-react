import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, AlertCircle } from 'lucide-react';
import { createIssue } from '../services/issueService';
import { useToast } from '../hooks/useToast';
import { CATEGORIES } from '../utils/constants';

const CreateIssue = () => {
  const [formData, setFormData] = useState({
    title: '',
    category: 'road',
    location: '',
    description: '',
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const { showToast } = useToast();

  const validate = () => {
    const e = {};
    if (!formData.title.trim()) e.title = 'Title is required';
    if (!formData.description.trim()) e.description = 'Description is required';
    if (formData.description.length < 10) e.description = 'Description must be at least 10 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      const issue = await createIssue({
        title: formData.title.trim(),
        description: formData.description.trim(),
        category: formData.category,
        location: formData.location.trim() || undefined,
      });
      showToast('Issue reported successfully!', 'success');
      navigate(`/issues/${issue._id}`);
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to submit issue', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page-padding">
      <div className="container-narrow">
        <div className="card" style={{ padding: '2rem' }}>
          <div className="text-center" style={{ marginBottom: '2rem' }}>
            <h2>Report a New Issue</h2>
            <p className="text-muted">Help improve the community by reporting local problems.</p>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Issue Title *</label>
              <input
                type="text"
                name="title"
                className="form-control"
                placeholder="e.g., Pothole on 5th Avenue"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
              {errors.title && <p className="form-error">{errors.title}</p>}
            </div>
            <div className="grid grid-2" style={{ gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Category *</label>
                <select
                  name="category"
                  className="form-control"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Location</label>
                <div className="input-icon-wrapper">
                  <MapPin className="input-icon" size={18} />
                  <input
                    type="text"
                    name="location"
                    className="form-control"
                    style={{ paddingLeft: '2.5rem' }}
                    placeholder="Address or landmark"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Description *</label>
              <textarea
                name="description"
                className="form-control"
                rows={5}
                placeholder="Describe the issue in detail..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
              {errors.description && <p className="form-error">{errors.description}</p>}
            </div>
            <div className="alert" style={{ background: 'var(--warning-soft)', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
              <AlertCircle size={22} style={{ color: 'var(--warning)', flexShrink: 0 }} />
              <p className="text-sm">In case of emergency, call 911 immediately. Do not use this form.</p>
            </div>
            <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={submitting} style={{ marginTop: '1rem' }}>
              {submitting ? <span className="spinner spinner-small" /> : 'Submit Report'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateIssue;
