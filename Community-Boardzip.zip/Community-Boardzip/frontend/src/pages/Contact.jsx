import { useState } from 'react';
import { Mail, User, MessageSquare, Send } from 'lucide-react';
import { sendContact } from '../services/contactService';
import { useToast } from '../hooks/useToast';
import { APP_NAME } from '../utils/constants';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitting, setSubmitting] = useState(false);
  const { showToast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await sendContact(form);
      showToast('Message sent successfully!', 'success');
      setForm({ name: '', email: '', subject: '', message: '' });
    } catch {
      showToast('Failed to send message', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page-padding">
      <div className="container" style={{ maxWidth: 700 }}>
        <div className="page-header text-center">
          <h1>Contact Us</h1>
          <p className="text-muted">Have questions about {APP_NAME}? We&apos;d love to hear from you.</p>
        </div>
        <div className="grid-split">
          <div className="card">
            <h3 style={{ marginBottom: '1rem' }}>Get in Touch</h3>
            <p className="text-muted text-sm" style={{ marginBottom: '1rem' }}>
              For platform support, partnership inquiries, or feedback about the community board.
            </p>
            <p className="flex gap-1 text-sm" style={{ alignItems: 'center', color: 'var(--text-muted)' }}>
              <Mail size={16} /> support@communityboard.app
            </p>
          </div>
          <div className="card">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Name</label>
                <div className="input-icon-wrapper">
                  <User className="input-icon" size={18} />
                  <input className="form-control" style={{ paddingLeft: '2.5rem' }} value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <div className="input-icon-wrapper">
                  <Mail className="input-icon" size={18} />
                  <input type="email" className="form-control" style={{ paddingLeft: '2.5rem' }} value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })} required />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Subject</label>
                <input className="form-control" value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea className="form-control" rows={5} value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })} required />
              </div>
              <button type="submit" className="btn btn-primary btn-full" disabled={submitting}>
                {submitting ? <span className="spinner spinner-small" /> : <><Send size={18} /> Send Message</>}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
