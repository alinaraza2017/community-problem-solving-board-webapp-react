import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FileText, CheckCircle, ThumbsUp, MessageSquare, Shield } from 'lucide-react';
import { getPostedIssues, getVotedIssues } from '../services/issueService';
import { useAuth } from '../hooks/useAuth';
import StatusBadge from '../components/common/StatusBadge';
import CategoryChart from '../components/common/CategoryChart';
import AnimatedCounter from '../components/common/AnimatedCounter';
import Spinner from '../components/common/Spinner';
import { formatDate } from '../utils/formatters';

const UserDashboard = () => {
  const { user, isAdmin } = useAuth();
  const [posted, setPosted] = useState([]);
  const [voted, setVoted] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('posted');

  useEffect(() => {
    Promise.all([getPostedIssues(), getVotedIssues()])
      .then(([p, v]) => {
        setPosted(p);
        setVoted(v);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const stats = user?.stats || {};
  const resolved = posted.filter((i) => i.status === 'resolved').length;
  const categoryData = Object.entries(
    posted.reduce((acc, i) => {
      acc[i.category] = (acc[i.category] || 0) + 1;
      return acc;
    }, {})
  ).map(([_id, count]) => ({ _id, count }));

  const list = tab === 'posted' ? posted : voted;

  if (loading) {
    return <div className="loader-container"><Spinner /></div>;
  }

  return (
    <div>
      <div style={{ marginBottom: '2rem' }} className="flex-between flex-wrap gap-2">
        <div>
          <h1>Welcome, {user?.username}</h1>
          <p className="text-muted">Manage your reported issues and community impact.</p>
        </div>
        {isAdmin && (
          <Link to="/admin" className="btn btn-primary">
            <Shield size={18} /> Admin Panel
          </Link>
        )}
      </div>

      <div className="grid grid-4" style={{ marginBottom: '2rem' }}>
        {[
          { icon: FileText, label: 'Issues Reported', value: stats.issuesReported ?? posted.length, color: 'var(--primary)' },
          { icon: CheckCircle, label: 'Resolved', value: stats.issuesResolved ?? resolved, color: 'var(--success)' },
          { icon: ThumbsUp, label: 'Upvotes Given', value: stats.upvotesGiven ?? voted.length, color: 'var(--warning)' },
          { icon: MessageSquare, label: 'Comments', value: stats.commentsCount ?? 0, color: '#7c3aed' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="card stat-card">
            <div className="stat-icon" style={{ background: `${color}18`, color }}>
              <Icon size={24} />
            </div>
            <div>
              <div className="stat-value"><AnimatedCounter end={value} /></div>
              <p className="text-muted text-sm">{label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-sidebar">
        <div className="card" style={{ padding: '1.5rem' }}>
          <div className="tabs">
            <button type="button" className={`tab-btn ${tab === 'posted' ? 'active' : ''}`} onClick={() => setTab('posted')}>
              My Reports ({posted.length})
            </button>
            <button type="button" className={`tab-btn ${tab === 'voted' ? 'active' : ''}`} onClick={() => setTab('voted')}>
              Upvoted ({voted.length})
            </button>
          </div>
          {list.length === 0 ? (
            <p className="text-muted text-center" style={{ padding: '2.5rem' }}>
              No issues yet. <Link to="/create-issue" style={{ fontWeight: 600 }}>Report one</Link>
            </p>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Votes</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((issue) => (
                    <tr key={issue._id}>
                      <td style={{ fontWeight: 600, color: 'var(--text-headers)' }}>{issue.title}</td>
                      <td className="text-muted text-sm">{formatDate(issue.createdAt)}</td>
                      <td><StatusBadge status={issue.status} /></td>
                      <td style={{ fontWeight: 700 }}>{issue.votes ?? 0}</td>
                      <td><Link to={`/issues/${issue._id}`} className="btn btn-outline btn-sm">View</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="card" style={{ height: 'fit-content' }}>
          <h3 style={{ marginBottom: '1.25rem', color: 'var(--text-headers)' }}>Issues by Category</h3>
          <CategoryChart data={categoryData} />
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
