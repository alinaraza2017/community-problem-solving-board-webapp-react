import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, FileText, CheckCircle, TrendingUp, Sparkles, MapPin, ThumbsUp } from 'lucide-react';
import { getIssues } from '../services/issueService';
import IssueCard from '../components/common/IssueCard';
import AnimatedCounter from '../components/common/AnimatedCounter';
import StatusBadge from '../components/common/StatusBadge';
import { CATEGORIES, APP_NAME } from '../utils/constants';
import { useAuth } from '../hooks/useAuth';

const TESTIMONIALS = [
  { name: 'Sarah M.', text: 'Reported a broken streetlight and it was fixed within a week. This platform actually works!', role: 'Resident' },
  { name: 'James K.', text: 'Love seeing what matters to my neighbors. Upvoting helps prioritize real problems.', role: 'Community Member' },
  { name: 'Maria L.', text: 'Finally a place where our voices are heard. Clean interface and easy to use.', role: 'Local Advocate' },
];

const Home = () => {
  const { isAuthenticated } = useAuth();
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getIssues()
      .then(setIssues)
      .catch(() => setIssues([]))
      .finally(() => setLoading(false));
  }, []);

  const recent = issues.slice(0, 3);
  const trending = [...issues].sort((a, b) => (b.votes || 0) - (a.votes || 0)).slice(0, 3);
  const resolved = issues.filter((i) => i.status === 'resolved').length;

  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="hero-badge">
              <Sparkles size={14} style={{ marginRight: 6 }} /> Civic Engagement Platform
            </span>
            <h1 style={{ marginBottom: '1.25rem' }}>
              Report. Discuss. <br />
              <span className="text-gradient">Resolve.</span>
            </h1>
            <p className="text-muted" style={{ fontSize: '1.05rem', lineHeight: '1.6', maxWidth: 520, marginBottom: '2rem' }}>
              {APP_NAME} connects residents with local issues — from road repairs to sanitation — so communities can track progress and drive real change.
            </p>
            <div className="flex gap-2 flex-wrap">
              <Link to={isAuthenticated ? '/create-issue' : '/register'} className="btn btn-primary btn-lg">
                Report an Issue <ArrowRight size={18} />
              </Link>
              <Link to="/issues" className="btn btn-outline btn-lg">
                Browse Issues
              </Link>
            </div>
            <div className="hero-stats">
              <div className="hero-stat">
                <strong><AnimatedCounter end={issues.length} /></strong>
                <span className="text-muted text-sm">Total Issues</span>
              </div>
              <div className="hero-stat" style={{ paddingLeft: '2rem', borderLeft: '1px solid var(--border)' }}>
                <strong><AnimatedCounter end={resolved} /></strong>
                <span className="text-muted text-sm">Resolved</span>
              </div>
              <div className="hero-stat" style={{ paddingLeft: '2rem', borderLeft: '1px solid var(--border)' }}>
                <strong><AnimatedCounter end={issues.reduce((s, i) => s + (i.votes || 0), 0)} /></strong>
                <span className="text-muted text-sm">Community Votes</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <h4 className="text-muted text-sm" style={{ textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
              Recent reports
            </h4>
            {recent.slice(0, 2).map((issue) => (
              <div key={issue._id} className="card card-glass hero-card-preview" style={{ padding: '1.25rem' }}>
                <div className="flex-between" style={{ marginBottom: '0.5rem' }}>
                  <StatusBadge status={issue.status} />
                  <span className="text-muted text-sm flex gap-1" style={{ alignItems: 'center' }}>
                    <ThumbsUp size={12} /> {issue.votes || 0}
                  </span>
                </div>
                <h4 style={{ margin: '0.25rem 0 0.5rem', fontSize: '1.05rem', color: 'var(--text-headers)' }}>{issue.title}</h4>
                <p className="text-muted text-sm flex gap-1" style={{ alignItems: 'center' }}>
                  <MapPin size={12} /> {issue.location || 'Reported Location'}
                </p>
              </div>
            ))}
            {!loading && recent.length === 0 && (
              <div className="card card-glass hero-card-preview text-center text-muted" style={{ padding: '2rem' }}>
                <FileText size={32} style={{ margin: '0 auto 0.75rem', color: 'var(--primary)', opacity: 0.8 }} />
                <p className="text-sm">Be the first to report a community issue!</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="section" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div className="grid grid-4">
            {[
              { icon: FileText, label: 'Issues Tracked', value: issues.length, color: 'var(--primary)' },
              { icon: CheckCircle, label: 'Resolved', value: resolved, color: 'var(--success)' },
              { icon: TrendingUp, label: 'Active', value: issues.length - resolved, color: 'var(--warning)' },
              { icon: Users, label: 'Categories', value: CATEGORIES.length, color: '#818cf8' },
            ].map(({ icon: Icon, label, value, color }) => (
              <div key={label} className="card stat-card" style={{ padding: '1.25rem 1.5rem' }}>
                <div className="stat-icon" style={{ background: `${color}10`, color }}>
                  <Icon size={22} />
                </div>
                <div>
                  <div className="stat-value"><AnimatedCounter end={value} /></div>
                  <p className="text-muted text-sm" style={{ fontWeight: 500, marginTop: '0.15rem' }}>{label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section-alt" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <h2 style={{ marginBottom: '0.5rem' }}>Browse by Category</h2>
            <p className="text-muted">Explore reports and issues categorized by community service areas.</p>
          </div>
          <div className="category-grid">
            {CATEGORIES.map((cat) => (
              <Link key={cat.value} to={`/issues?category=${cat.value}`} className="category-pill">
                <div className="icon">{cat.icon}</div>
                <strong style={{ color: 'var(--text-headers)', fontSize: '0.95rem' }}>{cat.label}</strong>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div className="flex-between" style={{ marginBottom: '2rem' }}>
            <div>
              <h2>Recent Issues</h2>
              <p className="text-muted">Latest reported issues from residents in your community.</p>
            </div>
            <Link to="/issues" className="btn btn-outline btn-sm">
              View All Issues <ArrowRight size={14} />
            </Link>
          </div>
          {loading ? (
            <div className="grid grid-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="skeleton skeleton-card" />
              ))}
            </div>
          ) : recent.length > 0 ? (
            <div className="grid grid-3">
              {recent.map((i) => (
                <div key={i._id} className="issue-card-wrapper" style={{ height: '100%' }}>
                  <IssueCard issue={i} />
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <FileText size={48} />
              <h3>No issues reported yet</h3>
              <p className="text-muted" style={{ margin: '0.5rem 0 1.25rem' }}>Be the first to bring attention to a local issue.</p>
              <Link to="/create-issue" className="btn btn-primary">Report an Issue</Link>
            </div>
          )}
        </div>
      </section>

      <section className="section section-alt" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ marginBottom: '2rem', textAlign: 'center' }}>
            <h2>Trending Issues</h2>
            <p className="text-muted">Community issues receiving the most activity and support.</p>
          </div>
          {loading ? (
            <div className="grid grid-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="skeleton skeleton-card" />
              ))}
            </div>
          ) : trending.length > 0 ? (
            <div className="grid grid-3">{trending.map((i) => <IssueCard key={i._id} issue={i} />)}</div>
          ) : (
            <p className="text-muted text-center">No trending issues yet.</p>
          )}
        </div>
      </section>

      <section className="section" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2>Community Impact</h2>
            <p className="text-muted">How reporting local issues creates transparency and active resolution.</p>
          </div>
          <div className="grid grid-3">
            {[
              { title: 'Faster Response', desc: 'Prioritized issues get immediate attention from local administrators and city moderators.' },
              { title: 'Transparent Tracking', desc: 'Follow every update step-by-step from reported to in-progress and successfully resolved.' },
              { title: 'Collective Voice', desc: 'Upvote cards help surface the most crucial problems that impact the entire community.' },
            ].map((item) => (
              <div key={item.title} className="card" style={{ padding: '2rem' }}>
                <h3 style={{ marginBottom: '0.75rem', fontSize: '1.2rem', color: 'var(--text-headers)' }}>{item.title}</h3>
                <p className="text-muted text-sm" style={{ lineHeight: 1.6 }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section-alt" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2>What Residents Say</h2>
            <p className="text-muted">Feedback from active users and neighborhood advocates.</p>
          </div>
          <div className="grid grid-3">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="card testimonial-card" style={{ padding: '2rem' }}>
                <p className="text-sm" style={{ marginBottom: '1.25rem', fontStyle: 'italic', lineHeight: 1.6 }}>"{t.text}"</p>
                <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1rem', marginTop: 'auto' }}>
                  <strong style={{ color: 'var(--text-headers)' }}>{t.name}</strong>
                  <p className="text-muted text-sm" style={{ marginTop: '0.15rem' }}>{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="card text-center" style={{ 
            padding: '4.5rem 2.5rem', 
            background: 'radial-gradient(circle at 100% 100%, var(--primary-soft), transparent), var(--bg-elevated)',
            borderColor: 'var(--primary-soft-border)',
            boxShadow: 'var(--shadow-lg)'
          }}>
            <h2 style={{ marginBottom: '0.75rem' }}>Ready to improve your neighborhood?</h2>
            <p className="text-muted text-sm" style={{ maxWidth: 520, margin: '0 auto 2rem', fontSize: '0.95rem' }}>
              Join hundreds of active residents who are collaborating to make our public spaces safer, cleaner, and better maintained.
            </p>
            <Link to={isAuthenticated ? '/create-issue' : '/register'} className="btn btn-primary btn-lg">
              Get Started Now <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
