import { useState, useEffect, useMemo, useCallback } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import { getIssues, upvoteIssue } from '../services/issueService';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { useDebounce } from '../hooks/useDebounce';
import IssueCard from '../components/common/IssueCard';
import SkeletonGrid from '../components/common/SkeletonGrid';
import EmptyState from '../components/common/EmptyState';
import { CATEGORIES, STATUSES } from '../utils/constants';

const Issues = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState('newest');
  const [upvotingId, setUpvotingId] = useState(null);
  const [searchParams] = useSearchParams();
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();
  const debouncedSearch = useDebounce(search);

  const loadIssues = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getIssues();
      setIssues(data);
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to load issues. Is the backend running and MongoDB connected?';
      showToast(msg, 'error');
      setIssues([]);
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    const cat = searchParams.get('category');
    if (cat) setCategory(cat);
    loadIssues();
  }, [searchParams, loadIssues]);

  const hasVoted = (issue) =>
    user && issue.voters?.some((v) => (typeof v === 'string' ? v : v._id || v)?.toString() === user.id?.toString());

  const handleUpvote = async (id) => {
    if (!isAuthenticated) {
      showToast('Please log in to upvote', 'error');
      return;
    }
    setUpvotingId(id);
    try {
      const res = await upvoteIssue(id);
      setIssues((prev) =>
        prev.map((i) =>
          i._id === id
            ? { ...i, votes: res.votes, voters: [...(i.voters || []), user.id] }
            : i
        )
      );
      showToast('Upvoted!', 'success');
    } catch (err) {
      showToast(err.response?.data?.message || 'Could not upvote', 'error');
    } finally {
      setUpvotingId(null);
    }
  };

  const filtered = useMemo(() => {
    let list = [...issues];
    if (debouncedSearch) {
      const q = debouncedSearch.toLowerCase();
      list = list.filter(
        (i) =>
          i.title?.toLowerCase().includes(q) ||
          i.description?.toLowerCase().includes(q) ||
          i.location?.toLowerCase().includes(q)
      );
    }
    if (category) list = list.filter((i) => i.category === category);
    if (status) list = list.filter((i) => i.status === status);
    if (sort === 'votes') list.sort((a, b) => (b.votes || 0) - (a.votes || 0));
    else if (sort === 'status') list.sort((a, b) => a.status.localeCompare(b.status));
    else list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return list;
  }, [issues, debouncedSearch, category, status, sort]);

  const [page, setPage] = useState(1);
  const perPage = 9;
  const totalPages = Math.ceil(filtered.length / perPage) || 1;
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  useEffect(() => setPage(1), [debouncedSearch, category, status, sort]);

  return (
    <div className="page-padding">
      <div className="container">
        <div className="page-header flex-between flex-wrap gap-2">
          <div>
            <h1>Community Issues</h1>
            <p className="text-muted">Browse, vote, and track local problems</p>
          </div>
          <Link to="/create-issue" className="btn btn-primary">Report Issue</Link>
        </div>

        <div className="filters-bar card">
          <div className="search-box">
            <Search size={18} />
            <input
              type="text"
              className="form-control"
              placeholder="Search issues..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select className="form-control" style={{ maxWidth: 180 }} value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="">All Categories</option>
            {CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
          <select className="form-control" style={{ maxWidth: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All Statuses</option>
            {STATUSES.map((s) => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
          <select className="form-control" style={{ maxWidth: 160 }} value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="newest">Newest First</option>
            <option value="votes">Most Voted</option>
            <option value="status">By Status</option>
          </select>
        </div>

        {loading ? (
          <SkeletonGrid />
        ) : paginated.length === 0 ? (
          <EmptyState
            title="No issues found"
            message="Try adjusting filters or report a new issue."
            action={<Link to="/create-issue" className="btn btn-primary" style={{ marginTop: '1rem' }}>Report Issue</Link>}
          />
        ) : (
          <>
            <div className="grid grid-3">
              {paginated.map((issue) => (
                <IssueCard
                  key={issue._id}
                  issue={issue}
                  onUpvote={handleUpvote}
                  hasVoted={hasVoted(issue)}
                  upvoting={upvotingId === issue._id}
                />
              ))}
            </div>
            {totalPages > 1 && (
              <div className="pagination">
                <button type="button" className="page-btn" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>‹</button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                  <button key={p} type="button" className={`page-btn ${page === p ? 'active' : ''}`} onClick={() => setPage(p)}>{p}</button>
                ))}
                <button type="button" className="page-btn" disabled={page === totalPages} onClick={() => setPage((p) => p + 1)}>›</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Issues;
