import { useState, useEffect } from 'react';
import { User, Mail, MapPin, FileText, MessageSquare, Calendar } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { getProfile, updateProfile } from '../services/userService';
import AnimatedCounter from '../components/common/AnimatedCounter';
import Spinner from '../components/common/Spinner';
import { formatDate, getInitials } from '../utils/formatters';

const Profile = () => {
  const { user, refreshProfile } = useAuth();
  const { showToast } = useToast();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ username: '', bio: '', location: '', contact: '' });

  useEffect(() => {
    getProfile()
      .then((data) => {
        setProfile(data);
        setForm({
          username: data.user.username || '',
          bio: data.user.profile?.bio || '',
          location: data.user.profile?.location || '',
          contact: data.user.profile?.contact || '',
        });
      })
      .catch(() => showToast('Failed to load profile', 'error'))
      .finally(() => setLoading(false));
  }, [showToast]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfile(user.id, {
        username: form.username,
        profile: { bio: form.bio, location: form.location, contact: form.contact },
      });
      await refreshProfile();
      const data = await getProfile();
      setProfile(data);
      setEditing(false);
      showToast('Profile updated', 'success');
    } catch (err) {
      showToast(err.response?.data?.message || 'Update failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="loader-container"><Spinner /></div>;
  if (!profile) return <p className="text-muted">Could not load profile.</p>;

  const { user: u, stats } = profile;

  return (
    <div>
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="flex gap-3" style={{ alignItems: 'flex-start', flexWrap: 'wrap' }}>
          <div className="avatar" style={{ width: 72, height: 72, fontSize: '1.5rem' }}>
            {getInitials(u.username)}
          </div>
          <div style={{ flex: 1 }}>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '0.35rem', color: 'var(--text-headers)' }}>{u.username}</h2>
            <p className="text-muted flex gap-1" style={{ alignItems: 'center', fontSize: '0.9rem' }}>
              <Mail size={14} /> {u.email}
            </p>
            <p className="text-muted text-sm flex gap-1" style={{ alignItems: 'center', marginTop: '0.35rem' }}>
              <Calendar size={14} /> Joined {formatDate(u.createdAt)}
            </p>
            {u.profile?.bio && !editing && <p style={{ marginTop: '0.75rem', fontSize: '0.95rem', color: 'var(--text)' }}>{u.profile.bio}</p>}
            {u.profile?.location && !editing && (
              <p className="text-muted text-sm flex gap-1" style={{ alignItems: 'center', marginTop: '0.35rem' }}>
                <MapPin size={14} /> {u.profile.location}
              </p>
            )}
          </div>
          <button type="button" className="btn btn-outline btn-sm" onClick={() => setEditing(!editing)}>
            {editing ? 'Cancel' : 'Edit Profile'}
          </button>
        </div>
      </div>

      <div className="grid grid-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { icon: FileText, label: 'Issues Reported', value: stats.issuesReported ?? 0 },
          { icon: FileText, label: 'Resolved', value: stats.issuesResolved ?? 0 },
          { icon: MessageSquare, label: 'Comments', value: stats.commentsCount ?? 0 },
          { icon: User, label: 'Upvotes Given', value: stats.upvotesGiven ?? 0 },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="card stat-card">
            <div className="stat-icon" style={{ background: 'var(--primary-soft)', color: 'var(--primary)' }}>
              <Icon size={22} />
            </div>
            <div>
              <div className="stat-value"><AnimatedCounter end={value} /></div>
              <p className="text-muted text-sm">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <div className="card">
          <h3 style={{ marginBottom: '1rem' }}>Edit Profile</h3>
          <form onSubmit={handleSave}>
            <div className="form-group">
              <label className="form-label">Username</label>
              <input className="form-control" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Bio</label>
              <textarea className="form-control" rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Location</label>
              <input className="form-control" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Contact</label>
              <input className="form-control" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} />
            </div>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? <span className="spinner spinner-small" /> : 'Save Changes'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Profile;
