import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';

const NotFound = () => (
  <div className="not-found page-padding">
    <h1>404</h1>
    <h2 style={{ marginBottom: '1rem' }}>Page Not Found</h2>
    <p className="text-muted" style={{ marginBottom: '2rem', maxWidth: 400, margin: '0 auto 2rem' }}>
      The page you&apos;re looking for doesn&apos;t exist or has been moved.
    </p>
    <div className="flex gap-2 flex-center flex-wrap">
      <Link to="/" className="btn btn-primary"><Home size={18} /> Go Home</Link>
      <Link to="/issues" className="btn btn-outline"><Search size={18} /> Browse Issues</Link>
    </div>
  </div>
);

export default NotFound;
