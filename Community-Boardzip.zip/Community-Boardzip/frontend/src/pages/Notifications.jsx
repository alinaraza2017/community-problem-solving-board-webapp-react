import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Bell, FileText, MessageSquare, ThumbsUp } from 'lucide-react';
import { getIssues } from '../services/issueService';
import { getPostedIssues } from '../services/issueService';
import { useAuth } from '../hooks/useAuth';
import Spinner from '../components/common/Spinner';
import EmptyState from '../components/common/EmptyState';
import { formatRelativeTime } from '../utils/formatters';

const Notifications = () => {
  const { user, isAuthenticated } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      setLoading(false);
      return;
    }
    const load = async () => {
      try {
        const [all, mine] = await Promise.all([getIssues(), getPostedIssues()]);
        const notifications = [];
        const myIds = new Set(mine.map((i) => i._id));

        all.slice(0, 10).forEach((issue) => {
          if (!myIds.has(issue._id) && (issue.votes || 0) >= 3) {
            notifications.push({
              id: `trend-${issue._id}`,
              type: 'trending',
              title: 'Trending issue in your area',
              message: `"${issue.title}" has ${issue.votes} upvotes`,
              link: `/issues/${issue._id}`,
              time: issue.updatedAt || issue.createdAt,
              unread: true,
            });
          }
        });

        mine.forEach((issue) => {
          if (issue.status === 'resolved') {
            notifications.push({
              id: `resolved-${issue._id}`,
              type: 'resolved',
              title: 'Your issue was resolved',
              message: `"${issue.title}" has been marked resolved`,
              link: `/issues/${issue._id}`,
              time: issue.updatedAt,
              unread: true,
            });
          } else if (issue.status === 'in progress') {
            notifications.push({
              id: `progress-${issue._id}`,
              type: 'progress',
              title: 'Issue in progress',
              message: `"${issue.title}" is being addressed`,
              link: `/issues/${issue._id}`,
              time: issue.updatedAt,
              unread: false,
            });
          }
        });

        notifications.sort((a, b) => new Date(b.time) - new Date(a.time));
        setItems(notifications);
      } catch {
        setItems([]);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [isAuthenticated]);

  const iconMap = {
    trending: ThumbsUp,
    resolved: FileText,
    progress: MessageSquare,
  };

  if (!isAuthenticated) {
    return (
      <EmptyState
        title="Sign in required"
        message="Log in to view your notifications."
        action={<Link to="/login" className="btn btn-primary" style={{ marginTop: '1rem' }}>Sign In</Link>}
      />
    );
  }

  if (loading) return <div className="loader-container"><Spinner /></div>;

  return (
    <div>
      <div className="page-header">
        <h1><Bell size={28} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 8 }} />Notifications</h1>
        <p className="text-muted">Updates on your issues and community activity</p>
      </div>
      {items.length === 0 ? (
        <EmptyState title="No notifications" message="You're all caught up!" />
      ) : (
        items.map((n) => {
          const Icon = iconMap[n.type] || Bell;
          return (
            <Link key={n.id} to={n.link} className={`notif-item ${n.unread ? 'unread' : ''}`} style={{ color: 'inherit' }}>
              <div className="stat-icon" style={{ width: 40, height: 40, background: 'var(--primary-soft)', color: 'var(--primary)', flexShrink: 0 }}>
                <Icon size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div className="flex-between" style={{ marginBottom: '0.15rem' }}>
                  <strong style={{ color: 'var(--text-headers)' }}>{n.title}</strong>
                  {n.unread && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--primary)', display: 'inline-block' }} />}
                </div>
                <p className="text-muted text-sm" style={{ marginBottom: '0.25rem' }}>{n.message}</p>
                <span className="text-muted text-sm" style={{ fontSize: '0.75rem' }}>{formatRelativeTime(n.time)}</span>
              </div>
            </Link>
          );
        })
      )}
    </div>
  );
};

export default Notifications;
