import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Users, FileText, CheckCircle, AlertTriangle, Trash2 } from 'lucide-react';
import { getAdminStats, updateIssueStatus, deleteIssueAdmin } from '../services/adminService';
import { getIssues } from '../services/issueService';
import { getAllUsers } from '../services/userService';
import { useToast } from '../hooks/useToast';
import AnimatedCounter from '../components/common/AnimatedCounter';
import CategoryChart from '../components/common/CategoryChart';
import StatusBadge from '../components/common/StatusBadge';
import Spinner from '../components/common/Spinner';
import { STATUSES } from '../utils/constants';
import { formatDate } from '../utils/formatters';

const SECTION_TITLES = {
  overview: { title: 'Admin Dashboard', subtitle: 'Platform overview and key metrics' },
  issues: { title: 'Manage Issues', subtitle: 'Moderate reports, update status, and remove issues' },
  users: { title: 'Manage Users', subtitle: 'View registered community members and roles' },
  analytics: { title: 'Reports & Analytics', subtitle: 'Category breakdown and trending issues' },
};

const AdminDashboard = () => {
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();
  const section = searchParams.get('section') || 'overview';

  const [stats, setStats] = useState(null);
  const [allIssues, setAllIssues] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [s, u, issues] = await Promise.all([getAdminStats(), getAllUsers(), getIssues()]);
      setStats(s);
      setUsers(u);
      setAllIssues(issues);
    } catch {
      showToast('Failed to load admin data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleStatusChange = async (id, status) => {
    try {
      await updateIssueStatus(id, status);
      showToast('Status updated', 'success');
      load();
    } catch {
      showToast('Failed to update status', 'error');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this issue permanently?')) return;
    try {
      await deleteIssueAdmin(id);
      showToast('Issue deleted', 'success');
      load();
    } catch {
      showToast('Failed to delete issue', 'error');
    }
  };

  const headings = SECTION_TITLES[section] || SECTION_TITLES.overview;
  const topVoted = stats?.topVoted || [];

  if (loading) {
    return (
      <div className="loader-container" style={{ minHeight: 280 }}>
        <Spinner />
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="page-header">
        <h1>{headings.title}</h1>
        <p className="text-muted">{headings.subtitle}</p>
      </div>

      {(section === 'overview' || section === 'analytics') && (
        <div className={`grid grid-4${section === 'analytics' ? '' : ''}`} style={{ marginBottom: '2rem' }}>
          {[
            { icon: Users, label: 'Total Users', value: stats?.totalUsers ?? 0, color: 'var(--primary)' },
            { icon: FileText, label: 'Total Issues', value: stats?.totalIssues ?? 0, color: '#7c3aed' },
            { icon: CheckCircle, label: 'Resolved', value: stats?.resolvedIssues ?? 0, color: 'var(--success)' },
            { icon: AlertTriangle, label: 'Active', value: stats?.activeIssues ?? 0, color: 'var(--warning)' },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="card stat-card">
              <div className="stat-icon" style={{ background: `${color}18`, color }}>
                <Icon size={24} />
              </div>
              <div>
                <div className="stat-value"><AnimatedCounter end={value} /></div>
                <p className="text-muted text-sm">{label}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {(section === 'overview' || section === 'analytics') && (
        <div className="grid-sidebar" style={{ marginBottom: section === 'overview' ? '2rem' : 0 }}>
          <div className="card">
            <h3 style={{ marginBottom: '1.25rem', color: 'var(--text-headers)' }}>Issues by Category</h3>
            <CategoryChart data={stats?.issuesByCategory || []} />
          </div>
          <div className="card" style={{ height: 'fit-content' }}>
            <h3 style={{ marginBottom: '1.25rem', color: 'var(--text-headers)' }}>Top Voted Issues</h3>
            {topVoted.length === 0 ? (
              <p className="text-muted text-sm">No issues yet</p>
            ) : (
              topVoted.map((issue) => (
                <div
                  key={issue._id}
                  className="flex-between"
                  style={{ padding: '0.65rem 0', borderBottom: '1px solid var(--border)' }}
                >
                  <Link to={`/issues/${issue._id}`} className="text-sm" style={{ fontWeight: 500, color: 'var(--text-headers)' }}>
                    {issue.title}
                  </Link>
                  <span className="badge badge-primary">{issue.votes} votes</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {section === 'overview' && (
        <div className="card" style={{ padding: '1.25rem' }}>
          <h3 style={{ marginBottom: '0.75rem', color: 'var(--text-headers)' }}>Quick actions</h3>
          <p className="text-muted text-sm" style={{ marginBottom: '1rem' }}>
            Use the admin menu to manage issues, users, and analytics.
          </p>
          <div className="flex gap-2 flex-wrap">
            <Link to="/admin?section=issues" className="btn btn-primary btn-sm">Manage Issues</Link>
            <Link to="/admin?section=users" className="btn btn-outline btn-sm">Manage Users</Link>
            <Link to="/admin?section=analytics" className="btn btn-outline btn-sm">View Analytics</Link>
          </div>
        </div>
      )}

      {section === 'issues' && (
        <div className="card" style={{ padding: '1.5rem' }}>
          <h3 style={{ marginBottom: '1.25rem', color: 'var(--text-headers)' }}>All reported issues</h3>
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Status</th>
                  <th>Votes</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {allIssues.map((issue) => (
                  <tr key={issue._id}>
                    <td style={{ fontWeight: 600 }}>
                      <Link to={`/issues/${issue._id}`} style={{ color: 'var(--text-headers)' }}>{issue.title}</Link>
                    </td>
                    <td><StatusBadge status={issue.status} /></td>
                    <td style={{ fontWeight: 700 }}>{issue.votes}</td>
                    <td className="text-muted text-sm">{formatDate(issue.createdAt)}</td>
                    <td>
                      <div className="flex gap-1" style={{ alignItems: 'center' }}>
                        <select
                          className="form-control"
                          style={{ maxWidth: 140, padding: '0.35rem', fontSize: '0.8rem' }}
                          value={issue.status}
                          onChange={(e) => handleStatusChange(issue._id, e.target.value)}
                        >
                          {STATUSES.map((s) => (
                            <option key={s.value} value={s.value}>{s.label}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          className="btn btn-icon"
                          onClick={() => handleDelete(issue._id)}
                          aria-label="Delete"
                          style={{ padding: '0.35rem' }}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {section === 'users' && (
        <div className="card" style={{ padding: '1.5rem' }}>
          <h3 style={{ marginBottom: '1.25rem', color: 'var(--text-headers)' }}>Registered users ({users.length})</h3>
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u._id}>
                    <td style={{ fontWeight: 600, color: 'var(--text-headers)' }}>{u.username}</td>
                    <td>{u.email}</td>
                    <td><span className="badge badge-primary">{u.role}</span></td>
                    <td className="text-muted text-sm">{formatDate(u.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
