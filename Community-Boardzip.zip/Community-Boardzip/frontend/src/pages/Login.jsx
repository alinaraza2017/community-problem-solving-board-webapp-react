import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, LogIn } from 'lucide-react';
import { login as loginApi } from '../services/authService';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { APP_NAME } from '../utils/constants';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const redirectTo = location.state?.from;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    try {
      const data = await loginApi(formData);
      login(data.token, {
        id: data.user.id,
        username: data.user.username,
        email: data.user.email,
        role: data.user.role,
      });
      showToast(`Welcome back, ${data.user.username}!`, 'success');
      const destination =
        redirectTo && (redirectTo !== '/login' && redirectTo !== '/register')
          ? redirectTo
          : data.user.role === 'admin'
            ? '/admin'
            : '/dashboard';
      navigate(destination, { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid email or password');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="card auth-card">
        <div className="auth-header">
          <h2>Welcome Back</h2>
          <p className="text-muted">Sign in to your {APP_NAME} account</p>
          <p className="text-muted text-sm" style={{ marginTop: '0.5rem' }}>
            Administrators use the same login with their admin account (role is assigned in the database).
          </p>
        </div>
        {error && <div className="alert alert-danger">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div className="input-icon-wrapper">
              <Mail className="input-icon" size={20} />
              <input type="email" name="email" className="form-control" placeholder="name@example.com"
                value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-icon-wrapper">
              <Lock className="input-icon" size={20} />
              <input type="password" name="password" className="form-control" placeholder="••••••••"
                value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })} required />
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-full" disabled={isLoading}>
            {isLoading ? <span className="spinner spinner-small" /> : <><LogIn size={20} /> Sign In</>}
          </button>
        </form>
        <div className="auth-footer">
          <p className="text-muted">Don&apos;t have an account? <Link to="/register">Create one</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Login;
