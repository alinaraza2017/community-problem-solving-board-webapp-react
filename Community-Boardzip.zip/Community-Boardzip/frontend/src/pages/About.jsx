import { Link } from 'react-router-dom';
import { Target, Users, Shield, ArrowRight } from 'lucide-react';
import { APP_NAME } from '../utils/constants';

const About = () => (
  <div className="page-padding">
    <div className="container">
      <div className="page-header text-center">
        <h1>About {APP_NAME}</h1>
        <p className="text-muted" style={{ maxWidth: 600, margin: '0 auto' }}>
          A civic technology platform empowering communities to report, discuss, and resolve local issues together.
        </p>
      </div>

      <div className="grid grid-3" style={{ marginBottom: '3rem' }}>
        {[
          { icon: Target, title: 'Our Mission', text: 'Make community problem-solving transparent, collaborative, and accessible to every resident.' },
          { icon: Users, title: 'Community First', text: 'Residents drive priorities through upvotes and comments, ensuring the most important issues get attention.' },
          { icon: Shield, title: 'Accountability', text: 'Track issue status from reported to resolved, with moderators ensuring quality and progress.' },
        ].map(({ icon: Icon, title, text }) => (
          <div key={title} className="card text-center">
            <div className="stat-icon" style={{ margin: '0 auto 1rem', background: 'var(--primary-soft)', color: 'var(--primary)' }}>
              <Icon size={28} />
            </div>
            <h3>{title}</h3>
            <p className="text-muted">{text}</p>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: '2.5rem', marginBottom: '2rem' }}>
        <h2 style={{ marginBottom: '1rem' }}>How It Works</h2>
        <ol style={{ paddingLeft: '1.25rem', color: 'var(--text-muted)', lineHeight: 2 }}>
          <li><strong style={{ color: 'var(--text)' }}>Report</strong> — Describe a community problem with location and category.</li>
          <li><strong style={{ color: 'var(--text)' }}>Discuss</strong> — Neighbors comment and upvote to prioritize issues.</li>
          <li><strong style={{ color: 'var(--text)' }}>Track</strong> — Follow status updates as issues move toward resolution.</li>
          <li><strong style={{ color: 'var(--text)' }}>Resolve</strong> — Admins and community leaders address top-voted issues.</li>
        </ol>
      </div>

      <div className="text-center">
        <Link to="/issues" className="btn btn-primary btn-lg">
          Explore Issues <ArrowRight size={18} />
        </Link>
      </div>
    </div>
  </div>
);

export default About;
