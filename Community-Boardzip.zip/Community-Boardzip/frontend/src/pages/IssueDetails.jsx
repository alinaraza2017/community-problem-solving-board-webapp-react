import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Clock, ArrowLeft, ThumbsUp } from 'lucide-react';
import { getIssue, upvoteIssue } from '../services/issueService';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import StatusBadge from '../components/common/StatusBadge';
import CommentSection from '../components/comments/CommentSection';
import Spinner from '../components/common/Spinner';
import { getCategoryLabel } from '../utils/constants';
import { formatDate } from '../utils/formatters';

const IssueDetails = () => {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();
  const [issue, setIssue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [upvoting, setUpvoting] = useState(false);

  useEffect(() => {
    getIssue(id)
      .then(setIssue)
      .catch(() => showToast('Issue not found', 'error'))
      .finally(() => setLoading(false));
  }, [id, showToast]);

  const hasVoted =
    user &&
    issue?.voters?.some((v) => (typeof v === 'string' ? v : v._id || v)?.toString() === user.id?.toString());

  const handleUpvote = async () => {
    if (!isAuthenticated) {
      showToast('Please log in to upvote', 'error');
      return;
    }
    if (hasVoted) return;
    setUpvoting(true);
    try {
      const res = await upvoteIssue(id);
      setIssue((prev) => ({
        ...prev,
        votes: res.votes,
        voters: [...(prev.voters || []), user.id],
      }));
      showToast('Upvoted!', 'success');
    } catch (err) {
      showToast(err.response?.data?.message || 'Could not upvote', 'error');
    } finally {
      setUpvoting(false);
    }
  };

  if (loading) {
    return (
      <div className="page-padding">
        <div className="container-narrow loader-container"><Spinner /></div>
      </div>
    );
  }

  if (!issue) {
    return (
      <div className="page-padding">
        <div className="container-narrow text-center">
          <h2>Issue not found</h2>
          <Link to="/issues" className="btn btn-primary" style={{ marginTop: '1rem' }}>Back to Issues</Link>
        </div>
      </div>
    );
  }

  const reporterName = issue.reporter?.username || issue.reporter?.profile?.name || 'Anonymous';

  return (
    <div className="page-padding">
      <div className="container-narrow">
        <Link to="/issues" className="btn btn-outline btn-sm" style={{ marginBottom: '1.5rem', display: 'inline-flex' }}>
          <ArrowLeft size={16} /> Back to Issues
        </Link>

        <article className="card" style={{ marginBottom: '2rem' }}>
          <div className="flex-between" style={{ marginBottom: '1.5rem' }}>
            <StatusBadge status={issue.status} />
            <span className="text-muted text-sm flex gap-1" style={{ alignItems: 'center', fontWeight: 500 }}>
              <Clock size={14} /> {formatDate(issue.createdAt)}
            </span>
          </div>
          <h1 style={{ marginBottom: '1rem', fontSize: '2rem', color: 'var(--text-headers)' }}>{issue.title}</h1>
          <div className="flex flex-wrap gap-2 text-muted text-sm" style={{ alignItems: 'center', marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border)' }}>
            {issue.location && (
              <span className="flex gap-1" style={{ alignItems: 'center', marginRight: '0.5rem' }}>
                <MapPin size={14} style={{ color: 'var(--primary)' }} /> <strong style={{ color: 'var(--text-headers)' }}>{issue.location}</strong>
              </span>
            )}
            <span style={{ marginRight: '0.5rem' }}>Category: <strong style={{ color: 'var(--text-headers)' }}>{getCategoryLabel(issue.category)}</strong></span>
            <span>Reported by: <strong style={{ color: 'var(--text-headers)' }}>{reporterName}</strong></span>
          </div>
          <p style={{ fontSize: '1.05rem', lineHeight: 1.7, marginBottom: '2rem', color: 'var(--text)' }}>{issue.description}</p>
          <div style={{ paddingTop: '0.5rem' }}>
            <button
              type="button"
              className={`btn ${hasVoted ? 'btn-ghost' : 'btn-primary'} btn-lg`}
              onClick={handleUpvote}
              disabled={upvoting || hasVoted}
              style={{ boxShadow: hasVoted ? 'none' : 'var(--shadow-md)' }}
            >
              <ThumbsUp size={18} />
              {hasVoted ? 'Upvoted' : 'Upvote'} ({issue.votes ?? 0})
            </button>
          </div>
        </article>

        <CommentSection issueId={id} />
      </div>
    </div>
  );
};

export default IssueDetails;
