import { Outlet } from 'react-router-dom';

/** Minimal wrapper for authenticated pages — navigation lives in Navbar only. */
const ProtectedLayout = () => (
  <div className="page-padding">
    <div className="container protected-page">
      <Outlet />
    </div>
  </div>
);

export default ProtectedLayout;
