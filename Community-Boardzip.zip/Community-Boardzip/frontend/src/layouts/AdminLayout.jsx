import { useState, useEffect } from 'react';
import { Link, Outlet, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Menu,
  X,
  Sun,
  Moon,
  LogOut,
  LayoutDashboard,
  FileText,
  Users,
  BarChart3,
  Settings,
  ExternalLink,
  Shield,
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useTheme } from '../hooks/useTheme';
import { APP_NAME } from '../utils/constants';
import { getInitials } from '../utils/formatters';

const NAV_ITEMS = [
  { section: 'overview', label: 'Admin Dashboard', icon: LayoutDashboard },
  { section: 'issues', label: 'Manage Issues', icon: FileText },
  { section: 'users', label: 'Manage Users', icon: Users },
  { section: 'analytics', label: 'Reports & Analytics', icon: BarChart3 },
];

const AdminLayout = () => {
  const { user, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const activeSection = searchParams.get('section') || 'overview';
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [searchParams]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navTo = (section) =>
    section === 'overview' ? '/admin' : `/admin?section=${section}`;

  const sidebarLinkClass = (section) => {
    const isActive =
      section === 'overview'
        ? activeSection === 'overview'
        : activeSection === section;
    return `admin-sidebar-link${isActive ? ' active' : ''}`;
  };

  return (
    <div className="admin-shell">
      <header className="admin-topbar">
        <div className="admin-topbar-inner">
          <button
            type="button"
            className="hamburger admin-hamburger"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Admin menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          <Link to="/admin" className="admin-brand">
            <span className="brand-icon admin-brand-icon">
              <Shield size={16} />
            </span>
            <span>
              <strong>{APP_NAME}</strong>
              <span className="admin-brand-sub">Admin Panel</span>
            </span>
          </Link>

          <div className="admin-topbar-actions">
            <button type="button" className="btn-icon" onClick={toggleTheme} aria-label="Toggle theme">
              {isDark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <span className="admin-topbar-user hide-mobile">
              <span className="avatar">{getInitials(user?.username)}</span>
              {user?.username}
            </span>
            <button type="button" className="btn btn-ghost btn-sm hide-mobile" onClick={handleLogout}>
              <LogOut size={16} /> Logout
            </button>
          </div>
        </div>
      </header>

      <div className="admin-body">
        <aside className={`admin-sidebar ${mobileOpen ? 'open' : ''}`}>
          <nav className="admin-sidebar-nav" aria-label="Admin navigation">
            <p className="admin-sidebar-label">Administration</p>
            {NAV_ITEMS.map(({ section, label, icon: Icon }) => (
              <Link key={section} to={navTo(section)} className={sidebarLinkClass(section)}>
                <Icon size={18} /> {label}
              </Link>
            ))}

            <p className="admin-sidebar-label" style={{ marginTop: '1.25rem' }}>Account</p>
            <Link to="/profile" className="admin-sidebar-link">
              <Settings size={18} /> Account Settings
            </Link>
            <Link to="/" className="admin-sidebar-link">
              <ExternalLink size={18} /> View Public Site
            </Link>
            <button type="button" className="admin-sidebar-link admin-sidebar-logout" onClick={handleLogout}>
              <LogOut size={18} /> Logout
            </button>
          </nav>
        </aside>

        {mobileOpen && (
          <button
            type="button"
            className="admin-sidebar-backdrop"
            aria-label="Close menu"
            onClick={() => setMobileOpen(false)}
          />
        )}

        <main className="admin-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
