import React, { createContext, useState, useEffect, useCallback } from 'react';
import { jwtDecode } from 'jwt-decode';
import { getProfile } from '../services/userService';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    const token = localStorage.getItem('token');
    if (!token) return null;
    try {
      const data = await getProfile();
      const profileUser = {
        id: data.user._id,
        username: data.user.username,
        email: data.user.email,
        role: data.user.role,
        profile: data.user.profile,
        createdAt: data.user.createdAt,
        stats: data.stats,
      };
      localStorage.setItem('user', JSON.stringify(profileUser));
      setUser(profileUser);
      return profileUser;
    } catch {
      logout();
      return null;
    }
  }, [logout]);

  useEffect(() => {
    const init = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          setLoading(false);
          return;
        }
        const decoded = jwtDecode(token);
        if (decoded.exp * 1000 < Date.now()) {
          logout();
          setLoading(false);
          return;
        }
        const stored = localStorage.getItem('user');
        if (stored) {
          const parsed = JSON.parse(stored);
          setUser({
            ...parsed,
            id: parsed.id || decoded.id,
            role: parsed.role || decoded.role,
          });
        } else {
          setUser({
            id: decoded.id,
            role: decoded.role,
            username: 'User',
          });
        }
        await refreshProfile();
      } catch {
        logout();
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [logout, refreshProfile]);

  const login = (token, userData) => {
    let role = userData.role;
    try {
      const decoded = jwtDecode(token);
      role = userData.role || decoded.role;
      userData = { ...userData, id: userData.id || decoded.id, role };
    } catch {
      /* use userData as provided */
    }
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        loading,
        refreshProfile,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
