import { getStatusMeta } from '../../utils/constants';

const StatusBadge = ({ status }) => {
  const meta = getStatusMeta(status);
  return <span className={`badge badge-${meta.color}`}>{meta.label}</span>;
};

export default StatusBadge;
