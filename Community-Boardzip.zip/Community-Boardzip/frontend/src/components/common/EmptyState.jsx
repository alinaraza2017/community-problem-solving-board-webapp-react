import { Inbox } from 'lucide-react';

const EmptyState = ({ title = 'Nothing here yet', message, action }) => (
  <div className="empty-state">
    <Inbox size={48} />
    <h3>{title}</h3>
    {message && <p className="text-muted">{message}</p>}
    {action}
  </div>
);

export default EmptyState;
