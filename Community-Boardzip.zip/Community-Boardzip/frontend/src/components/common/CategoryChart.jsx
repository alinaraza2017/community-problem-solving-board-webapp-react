import { getCategoryLabel } from '../../utils/constants';

const CategoryChart = ({ data = [] }) => {
  const max = Math.max(...data.map((d) => d.count), 1);
  return (
    <div className="chart-bar-wrap">
      {data.length === 0 ? (
        <p className="text-muted text-sm">No data yet</p>
      ) : (
        data.map((item) => (
          <div key={item._id} className="chart-bar-row">
            <span className="chart-bar-label">{getCategoryLabel(item._id)}</span>
            <div className="chart-bar-track">
              <div className="chart-bar-fill" style={{ width: `${(item.count / max) * 100}%` }} />
            </div>
            <span className="chart-bar-value">{item.count}</span>
          </div>
        ))
      )}
    </div>
  );
};

export default CategoryChart;
