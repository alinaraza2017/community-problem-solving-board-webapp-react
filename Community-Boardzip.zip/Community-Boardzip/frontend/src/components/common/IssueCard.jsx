import { Link } from 'react-router-dom';
import { MapPin, ArrowUp } from 'lucide-react';
import StatusBadge from './StatusBadge';
import { getCategoryLabel } from '../../utils/constants';
import { formatDate } from '../../utils/formatters';

const IssueCard = ({ issue, onUpvote, hasVoted, upvoting }) => (
  <article className="card issue-card" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
    <div className="issue-card-header" style={{ display: 'flex', justifyContent: 'between', alignItems: 'center', marginBottom: '0.75rem' }}>
      <StatusBadge status={issue.status} />
      <span className="text-muted text-sm">{formatDate(issue.createdAt)}</span>
    </div>
    <h3 className="issue-title" style={{ marginBottom: '0.5rem', lineHeight: '1.4' }}>
      <Link to={`/issues/${issue._id}`} style={{ color: 'var(--text-headers)' }}>{issue.title}</Link>
    </h3>
    <p className="text-muted text-sm" style={{ 
      display: '-webkit-box', 
      WebkitLineClamp: 2, 
      WebkitBoxOrient: 'vertical', 
      overflow: 'hidden',
      marginBottom: '1rem',
      lineHeight: '1.5'
    }}>
      {issue.description}
    </p>
    <p className="text-muted text-sm flex gap-1" style={{ alignItems: 'center', marginTop: 'auto', marginBottom: '1.25rem' }}>
      <MapPin size={14} style={{ color: 'var(--primary)', opacity: 0.8 }} /> 
      <span style={{ fontWeight: 500 }}>{getCategoryLabel(issue.category)}</span>
      {issue.location && <span style={{ color: 'var(--border-hover)' }}>·</span>}
      {issue.location && <span style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>{issue.location}</span>}
    </p>
    <div className="issue-card-footer" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '1rem', borderTop: '1px solid var(--border)' }}>
      <div className="vote-group" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <button
          type="button"
          className={`btn-vote ${hasVoted ? 'voted' : ''}`}
          onClick={(e) => {
            e.preventDefault();
            onUpvote?.(issue._id);
          }}
          disabled={upvoting || hasVoted}
          aria-label="Upvote"
        >
          <ArrowUp size={16} />
        </button>
        <span style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-headers)' }}>{issue.votes ?? 0}</span>
      </div>
      <Link to={`/issues/${issue._id}`} className="btn btn-outline btn-sm">
        View Details
      </Link>
    </div>
  </article>
);

export default IssueCard;
