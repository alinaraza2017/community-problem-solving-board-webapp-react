const Spinner = ({ small }) => (
  <div className={small ? 'spinner spinner-small' : 'spinner'} role="status" aria-label="Loading" />
);

export default Spinner;
