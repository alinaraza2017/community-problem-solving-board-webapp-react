const SkeletonGrid = ({ count = 6 }) => (
  <div className="grid grid-2">
    {Array.from({ length: count }).map((_, i) => (
      <div key={i} className="skeleton skeleton-card" />
    ))}
  </div>
);

export default SkeletonGrid;
