import { useState, useRef, useEffect } from 'react';
import { Link, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, Sun, Moon, Bell, LogOut, LayoutDashboard, User, Shield, PlusCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useTheme } from '../hooks/useTheme';
import { APP_NAME } from '../utils/constants';
import { getInitials } from '../utils/formatters';

const Navbar = () => {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/');
    setUserMenuOpen(false);
    setMobileOpen(false);
  };

  const navLink = ({ isActive }) => `nav-link ${isActive ? 'active' : ''}`;
  const closeMobile = () => setMobileOpen(false);

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="navbar-brand" onClick={closeMobile}>
          <span className="brand-icon">CB</span>
          {APP_NAME}
        </Link>

        <nav className="nav-links hide-mobile">
          <NavLink to="/" end className={navLink}>Home</NavLink>
          <NavLink to="/issues" className={navLink}>Issues</NavLink>
          <NavLink to="/about" className={navLink}>About</NavLink>
          <NavLink to="/contact" className={navLink}>Contact</NavLink>
          {isAuthenticated && (
            <>
              <NavLink to="/dashboard" className={navLink}>Dashboard</NavLink>
              <NavLink to="/create-issue" className={navLink}>Report Issue</NavLink>
              {isAdmin && (
                <NavLink to="/admin" className={navLink}>
                  <span className="nav-admin-label"><Shield size={14} /> Admin</span>
                </NavLink>
              )}
            </>
          )}
        </nav>

        <div className="nav-actions" ref={menuRef}>
          <button type="button" className="btn-icon" onClick={toggleTheme} aria-label="Toggle theme">
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {isAuthenticated && (
            <div className="dropdown hide-mobile">
              <button
                type="button"
                className="btn-icon"
                onClick={() => { setNotifOpen(!notifOpen); setUserMenuOpen(false); }}
                aria-label="Notifications"
              >
                <Bell size={18} />
              </button>
              {notifOpen && (
                <div className="dropdown-menu" style={{ width: 260, padding: '0.5rem' }}>
                  <p className="text-muted text-sm" style={{ padding: '0.4rem 0.6rem', fontWeight: 600, borderBottom: '1px solid var(--border)', marginBottom: '0.4rem' }}>
                    Notifications
                  </p>
                  <div style={{ padding: '0.6rem 0.4rem', textAlign: 'center' }}>
                    <p className="text-muted text-sm" style={{ marginBottom: '0.75rem' }}>View updates and activity</p>
                    <Link to="/notifications" className="btn btn-primary btn-sm btn-full" onClick={() => setNotifOpen(false)}>
                      Open Inbox
                    </Link>
                  </div>
                </div>
              )}
            </div>
          )}

          {isAuthenticated ? (
            <div className="dropdown hide-mobile">
              <button
                type="button"
                className="nav-user"
                onClick={() => { setUserMenuOpen(!userMenuOpen); setNotifOpen(false); }}
              >
                <span className="avatar">{getInitials(user?.username)}</span>
                <span className="text-sm nav-username">{user?.username}</span>
                {isAdmin && <span className="badge badge-primary nav-role-badge">Admin</span>}
              </button>
              {userMenuOpen && (
                <div className="dropdown-menu">
                  <Link to="/dashboard" className="dropdown-item" onClick={() => setUserMenuOpen(false)}>
                    <LayoutDashboard size={16} /> Dashboard
                  </Link>
                  <Link to="/create-issue" className="dropdown-item" onClick={() => setUserMenuOpen(false)}>
                    <PlusCircle size={16} /> Report Issue
                  </Link>
                  <Link to="/profile" className="dropdown-item" onClick={() => setUserMenuOpen(false)}>
                    <User size={16} /> Profile
                  </Link>
                  {isAdmin && (
                    <Link to="/admin" className="dropdown-item dropdown-item-admin" onClick={() => setUserMenuOpen(false)}>
                      <Shield size={16} /> Admin Panel
                    </Link>
                  )}
                  <button type="button" className="dropdown-item" onClick={handleLogout}>
                    <LogOut size={16} /> Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="hide-mobile flex gap-1">
              <Link to="/login" className="btn btn-ghost btn-sm">Login</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Sign Up</Link>
            </div>
          )}

          <button type="button" className="hamburger" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <div className={`mobile-menu ${mobileOpen ? 'open' : ''}`}>
        <NavLink to="/" end className={navLink} onClick={closeMobile}>Home</NavLink>
        <NavLink to="/issues" className={navLink} onClick={closeMobile}>Issues</NavLink>
        <NavLink to="/about" className={navLink} onClick={closeMobile}>About</NavLink>
        <NavLink to="/contact" className={navLink} onClick={closeMobile}>Contact</NavLink>
        {isAuthenticated ? (
          <>
            <NavLink to="/dashboard" className={navLink} onClick={closeMobile}>Dashboard</NavLink>
            <NavLink to="/create-issue" className={navLink} onClick={closeMobile}>Report Issue</NavLink>
            <NavLink to="/profile" className={navLink} onClick={closeMobile}>Profile</NavLink>
            <NavLink to="/notifications" className={navLink} onClick={closeMobile}>Notifications</NavLink>
            {isAdmin && (
              <NavLink to="/admin" className={navLink} onClick={closeMobile}>
                <Shield size={16} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />
                Admin Panel
              </NavLink>
            )}
            <button type="button" className="btn btn-outline btn-full" onClick={handleLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn btn-ghost btn-full" onClick={closeMobile}>Login</Link>
            <Link to="/register" className="btn btn-primary btn-full" onClick={closeMobile}>Sign Up</Link>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
