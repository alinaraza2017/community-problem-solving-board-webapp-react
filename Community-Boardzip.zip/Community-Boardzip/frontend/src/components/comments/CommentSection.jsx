import { useState, useEffect } from 'react';
import { MessageSquare } from 'lucide-react';
import { getComments, postComment } from '../../services/commentService';
import { useAuth } from '../../hooks/useAuth';
import { useToast } from '../../hooks/useToast';
import { formatRelativeTime, getInitials } from '../../utils/formatters';
import Spinner from '../common/Spinner';
import EmptyState from '../common/EmptyState';

const CommentSection = ({ issueId }) => {
  const { isAuthenticated } = useAuth();
  const { showToast } = useToast();
  const [comments, setComments] = useState([]);
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const loadComments = async () => {
    try {
      const data = await getComments(issueId);
      setComments(data);
    } catch {
      showToast('Failed to load comments', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadComments();
  }, [issueId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    setSubmitting(true);
    try {
      await postComment({ content: content.trim(), issue: issueId });
      await loadComments();
      setContent('');
      showToast('Comment posted', 'success');
    } catch (err) {
      showToast(err.response?.data?.message || err.response?.data?.error || 'Failed to post comment', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="card">
      <h3 style={{ marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <MessageSquare size={20} /> Comments ({comments.length})
      </h3>

      {loading ? (
        <Spinner />
      ) : comments.length === 0 ? (
        <EmptyState title="No comments yet" message="Be the first to share your thoughts." />
      ) : (
        <div style={{ marginBottom: '1.5rem' }}>
          {comments.map((c) => (
            <div key={c._id} className="comment-item">
              <div className="comment-header">
                <div className="flex gap-2" style={{ alignItems: 'center' }}>
                  <span className="avatar" style={{ width: 28, height: 28, fontSize: '0.65rem' }}>
                    {getInitials(c.user?.username || c.user?.profile?.name || 'U')}
                  </span>
                  <span className="comment-author">{c.user?.username || 'User'}</span>
                </div>
                <span className="text-muted text-sm">{formatRelativeTime(c.createdAt)}</span>
              </div>
              <p>{c.content}</p>
            </div>
          ))}
        </div>
      )}

      {isAuthenticated ? (
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <textarea
              className="form-control"
              rows={3}
              placeholder="Add a comment..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? <span className="spinner spinner-small" /> : 'Post Comment'}
          </button>
        </form>
      ) : (
        <p className="text-muted text-sm">Please log in to post a comment.</p>
      )}
    </div>
  );
};

export default CommentSection;
