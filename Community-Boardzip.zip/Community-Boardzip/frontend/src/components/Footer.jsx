import { Link } from 'react-router-dom';
import { APP_NAME } from '../utils/constants';

const Footer = () => (
  <footer className="footer">
    <div className="container">
      <div className="footer-grid">
        <div className="footer-col">
          <Link to="/" className="navbar-brand" style={{ marginBottom: '1rem' }}>
            <span className="brand-icon">CB</span>
            {APP_NAME}
          </Link>
          <p>A civic platform for reporting community problems, tracking resolutions, and building stronger neighborhoods together.</p>
        </div>
        <div className="footer-col">
          <h4>Platform</h4>
          <Link to="/issues">Community Issues</Link>
          <Link to="/create-issue">Report Issue</Link>
          <Link to="/dashboard">Dashboard</Link>
        </div>
        <div className="footer-col">
          <h4>Company</h4>
          <Link to="/about">About Us</Link>
          <Link to="/contact">Contact</Link>
          <Link to="/notifications">Notifications</Link>
        </div>
        <div className="footer-col">
          <h4>Account</h4>
          <Link to="/login">Login</Link>
          <Link to="/register">Sign Up</Link>
          <Link to="/profile">Profile</Link>
        </div>
      </div>
      <div className="footer-bottom">
        © {new Date().getFullYear()} {APP_NAME}. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
