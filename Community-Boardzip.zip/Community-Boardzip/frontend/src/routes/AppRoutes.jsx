import { useContext } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import ProtectedLayout from '../layouts/ProtectedLayout';
import AdminLayout from '../layouts/AdminLayout';
import Spinner from '../components/common/Spinner';

import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Issues from '../pages/Issues';
import IssueDetails from '../pages/IssueDetails';
import CreateIssue from '../pages/CreateIssue';
import UserDashboard from '../pages/UserDashboard';
import Profile from '../pages/Profile';
import Notifications from '../pages/Notifications';
import AdminDashboard from '../pages/AdminDashboard';
import About from '../pages/About';
import Contact from '../pages/Contact';
import NotFound from '../pages/NotFound';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useContext(AuthContext);
  if (loading) return <div className="loader-container"><Spinner /></div>;
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

const AdminRoute = ({ children }) => {
  const { isAuthenticated, isAdmin, loading } = useContext(AuthContext);
  if (loading) return <div className="loader-container"><Spinner /></div>;
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: '/admin' }} />;
  if (!isAdmin) return <Navigate to="/dashboard" replace />;
  return children;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/issues" element={<Issues />} />
    <Route path="/issues/:id" element={<IssueDetails />} />
    <Route path="/about" element={<About />} />
    <Route path="/contact" element={<Contact />} />

    <Route element={<ProtectedRoute><ProtectedLayout /></ProtectedRoute>}>
      <Route path="/dashboard" element={<UserDashboard />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="/create-issue" element={<CreateIssue />} />
    </Route>

    <Route path="/admin" element={<AdminRoute><AdminLayout /></AdminRoute>}>
      <Route index element={<AdminDashboard />} />
    </Route>
    <Route path="*" element={<NotFound />} />
  </Routes>
);

export default AppRoutes;
