import React from 'react';
import { BrowserRouter as Router, useLocation } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

function AppShell() {
  const { pathname } = useLocation();
  const isAdminArea = pathname.startsWith('/admin');

  return (
    <div className={`app-container${isAdminArea ? ' app-container-admin' : ''}`}>
      {!isAdminArea && <Navbar />}
      <main className={isAdminArea ? 'admin-main-wrapper' : 'main-content'}>
        <AppRoutes />
      </main>
      {!isAdminArea && <Footer />}
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppShell />
    </Router>
  );
}

export default App;
