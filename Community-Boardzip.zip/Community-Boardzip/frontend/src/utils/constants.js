export const APP_NAME = 'Community Board';

export const CATEGORIES = [
  { value: 'road', label: 'Road & Infrastructure', icon: '🛣️' },
  { value: 'lighting', label: 'Street Lighting', icon: '💡' },
  { value: 'sanitation', label: 'Sanitation & Waste', icon: '🗑️' },
  { value: 'other', label: 'Other', icon: '📋' },
];

export const STATUSES = [
  { value: 'reported', label: 'Reported', color: 'primary' },
  { value: 'in progress', label: 'In Progress', color: 'warning' },
  { value: 'resolved', label: 'Resolved', color: 'success' },
];

export const getCategoryLabel = (value) =>
  CATEGORIES.find((c) => c.value === value)?.label || value;

export const getStatusMeta = (value) =>
  STATUSES.find((s) => s.value === value) || { label: value, color: 'primary' };
