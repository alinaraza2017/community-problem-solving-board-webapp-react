const mongoose = require('mongoose');

const DEFAULT_DB_NAME = 'communityboard';

/**
 * Resolves the database name — always communityboard unless overridden in .env.
 */
function getDatabaseName() {
  const name = (process.env.MONGO_DB_NAME || DEFAULT_DB_NAME).trim();
  return name || DEFAULT_DB_NAME;
}

/**
 * Returns true if the connection string already includes a database path segment.
 */
function uriHasDatabaseName(uri) {
  return /mongodb(\+srv)?:\/\/[^/]+\/[^/?]+/.test(uri);
}

/**
 * Inserts the database name into Atlas-style URIs that end with .net/? or .net/
 * Example: ...mongodb.net/?appName=CB → ...mongodb.net/communityboard?appName=CB
 */
function ensureDatabaseInUri(uri, dbName) {
  if (uriHasDatabaseName(uri)) {
    return uri;
  }

  const qIndex = uri.indexOf('?');
  if (qIndex === -1) {
    const base = uri.endsWith('/') ? uri.slice(0, -1) : uri;
    return `${base}/${dbName}`;
  }

  const beforeQuery = uri.slice(0, qIndex);
  const query = uri.slice(qIndex);
  const base = beforeQuery.endsWith('/') ? beforeQuery.slice(0, -1) : beforeQuery;
  return `${base}/${dbName}${query}`;
}

/**
 * Shared Mongo options used by server, seed scripts, and migrations.
 */
function getMongoConfig() {
  const rawUri = process.env.MONGO_URI;
  if (!rawUri || !rawUri.trim()) {
    throw new Error('MONGO_URI is not defined in .env');
  }

  const dbName = getDatabaseName();
  const uri = ensureDatabaseInUri(rawUri.trim(), dbName);

  return {
    uri,
    dbName,
    options: { dbName },
  };
}

const connectDB = async () => {
  const { uri, dbName, options } = getMongoConfig();

  await mongoose.connect(uri, options);

  const active = mongoose.connection.name;
  if (active !== dbName) {
    console.warn(
      `Warning: expected database "${dbName}" but mongoose connected to "${active}". Check MONGO_URI and MONGO_DB_NAME.`
    );
  }

  console.log(`Connected to MongoDB database: ${active}`);
  return mongoose.connection;
};

module.exports = connectDB;
module.exports.getMongoConfig = getMongoConfig;
module.exports.getDatabaseName = getDatabaseName;
module.exports.ensureDatabaseInUri = ensureDatabaseInUri;
