/**
 * Copies collections from the legacy "test" database into "communityboard"
 * without deleting anything in "test".
 *
 * Run once if users/issues were created in test by mistake:
 *   npm run migrate:test-db
 */

require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { getDatabaseName } = require('../config/db');

const User = require('../models/User');
const Issue = require('../models/Issue');
const Comment = require('../models/comment');
const Feedback = require('../models/feedback');
const Contact = require('../models/Contact');

const COLLECTIONS = [
  User.collection.name,
  Issue.collection.name,
  Comment.collection.name,
  Feedback.collection.name,
  Contact.collection.name,
];

async function copyCollection(sourceDb, targetDb, name) {
  const source = sourceDb.collection(name);
  const target = targetDb.collection(name);
  const docs = await source.find({}).toArray();

  if (docs.length === 0) {
    console.log(`  ${name}: nothing in test`);
    return { copied: 0, skipped: 0 };
  }

  let copied = 0;
  let skipped = 0;

  for (const doc of docs) {
    const filter = doc._id ? { _id: doc._id } : { _id: new mongoose.Types.ObjectId() };
    const existing = await target.findOne({ _id: doc._id });
    if (existing) {
      skipped += 1;
      continue;
    }
    await target.insertOne(doc);
    copied += 1;
  }

  console.log(`  ${name}: copied ${copied}, skipped ${skipped} (already in ${getDatabaseName()})`);
  return { copied, skipped };
}

async function migrate() {
  const targetName = getDatabaseName();

  try {
    await connectDB();
    const client = mongoose.connection.getClient();
    const testDb = client.db('test');
    const targetDb = client.db(targetName);

    const testCollections = await testDb.listCollections().toArray();
    const testNames = testCollections.map((c) => c.name);
    console.log(`\nSource: test (${testNames.length} collections)`);
    console.log(`Target: ${targetName}\n`);

    let totalCopied = 0;
    for (const name of COLLECTIONS) {
      if (!testNames.includes(name)) {
        console.log(`  ${name}: not found in test`);
        continue;
      }
      const { copied } = await copyCollection(testDb, targetDb, name);
      totalCopied += copied;
    }

    console.log(`\nMigration finished. ${totalCopied} document(s) copied into "${targetName}".`);
    console.log('The "test" database was not modified or deleted.\n');
  } catch (err) {
    console.error('Migration failed:', err.message);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
}

migrate();
