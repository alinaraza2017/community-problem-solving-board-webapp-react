/**
 * Admin seeder — run once (or after DB reset):
 *   npm run seed:admin
 *
 * Uses the same DB connection as the server (communityboard).
 */

require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const connectDB = require('../config/db');
const { getDatabaseName } = require('../config/db');
const User = require('../models/User');

const SALT_ROUNDS = 12;

function buildAdminList() {
  const list = [];
  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    list.push({
      username: process.env.ADMIN_USERNAME || 'Admin',
      email: process.env.ADMIN_EMAIL.trim().toLowerCase(),
      password: process.env.ADMIN_PASSWORD,
    });
  }
  if (process.env.ADMIN2_EMAIL && process.env.ADMIN2_PASSWORD) {
    list.push({
      username: process.env.ADMIN2_USERNAME || 'Admin 2',
      email: process.env.ADMIN2_EMAIL.trim().toLowerCase(),
      password: process.env.ADMIN2_PASSWORD,
    });
  }
  return list;
}

async function upsertAdmin({ username, email, password }) {
  const existing = await User.findOne({ email });

  if (existing) {
    let changed = false;
    if (existing.role !== 'admin') {
      existing.role = 'admin';
      changed = true;
    }
    if (password) {
      existing.password = await bcrypt.hash(password, SALT_ROUNDS);
      changed = true;
    }
    if (changed) {
      await existing.save();
      console.log(`Updated existing user to admin: ${email}`);
    } else {
      console.log(`Admin already configured, skipping: ${email}`);
    }
    return;
  }

  const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
  await User.create({
    username,
    email,
    password: hashedPassword,
    role: 'admin',
  });
  console.log(`Created admin: ${email}`);
}

async function createAdmins() {
  const admins = buildAdminList();

  if (admins.length === 0) {
    console.error('\nNo admin credentials in .env.');
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD, then run: npm run seed:admin\n');
    process.exit(1);
  }

  try {
    await connectDB();
    console.log(`Seeding admins in database: ${getDatabaseName()}\n`);

    for (const admin of admins) {
      await upsertAdmin(admin);
    }

    console.log('\nDone. Sign in at /login with the admin email and password from .env.');
  } catch (err) {
    console.error('Error seeding admins:', err.message);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
}

createAdmins();
