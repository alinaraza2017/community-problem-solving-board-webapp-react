const mongoose = require('mongoose');

const issueSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  category: { type: String, enum: ['road', 'lighting', 'sanitation', 'other'], required: true },
  location: { type: String, trim: true },
  status: { type: String, enum: ['reported', 'in progress', 'resolved'], default: 'reported' },
  votes: { type: Number, default: 0 },
  //array
  voters: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  reporter: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true });

module.exports = mongoose.models.Issue || mongoose.model('Issue', issueSchema);
