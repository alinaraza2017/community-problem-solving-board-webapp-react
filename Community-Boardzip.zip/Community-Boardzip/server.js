const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const connectDB = require('./config/db');

// Routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const issueRoutes = require('./routes/issues');
const commentRoutes = require('./routes/comments');
const feedbackRoutes = require('./routes/feedback');
const contactRoutes = require('./routes/contact');
const adminRoutes = require('./routes/admin');

const { errorHandler, notFound } = require('./middlewares/errorHandler');

const app = express();

// Middleware
app.use(cors({ origin: ['http://localhost:5173', 'http://localhost:4173'], credentials: true }));
app.use(express.json());

// Health check — confirms API is up AND database is connected
app.get('/api/health', (req, res) => {
  const dbState = mongoose.connection.readyState;
  const dbStatus = { 0: 'disconnected', 1: 'connected', 2: 'connecting', 3: 'disconnecting' }[dbState];
  res.json({
    ok: dbState === 1,
    database: dbStatus,
    databaseName: mongoose.connection.name || null,
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/issues', issueRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/admin', adminRoutes);

// Error Handling Middlewares
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Active MongoDB database: ${mongoose.connection.name}`);
    });
  } catch (err) {
    console.error('\n❌ Failed to start server — MongoDB is not connected.\n');
    console.error(err.message);
    console.error('\nFix checklist:');
    console.error('  1. MongoDB Atlas → Network Access → add your IP (or 0.0.0.0/0 for dev only)');
    console.error('  2. Verify MONGO_URI username/password in .env');
    console.error('  3. Add database name: ...mongodb.net/communityboard?retryWrites=true&w=majority');
    console.error('  4. Or use local MongoDB: MONGO_URI=mongodb://127.0.0.1:27017/communityboard\n');
    process.exit(1);
  }
};

startServer();
