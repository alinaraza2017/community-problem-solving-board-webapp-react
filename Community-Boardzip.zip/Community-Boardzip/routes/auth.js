const express = require('express');
const router = express.Router();
const validate = require('../middlewares/validate');
const { signup, login, signupSchema, loginSchema } = require('../controllers/authController');

router.post('/signup', validate(signupSchema), signup);
router.post('/login', validate(loginSchema), login);

module.exports = router;
