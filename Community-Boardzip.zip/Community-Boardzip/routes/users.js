const express = require('express');
const router = express.Router();
const validate = require('../middlewares/validate');
const { protect, authorize } = require('../middlewares/authMiddleware');
const {
  getProfile,
  getUsers,
  getUserById,
  updateUserProfile,
  updateUserSchema
} = require('../controllers/userController');

router.get('/profile', protect, getProfile);

router.route('/')
  .get(protect, authorize('admin'), getUsers);

router.route('/:id')
  .get(getUserById)
  .put(protect, validate(updateUserSchema), updateUserProfile);

module.exports = router;
