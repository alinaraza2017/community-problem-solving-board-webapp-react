const router = require('express').Router();
const Comment = require('../models/comment');
const auth = require('../middlewares/authMiddleware').protect;

// CREATE COMMENT
router.post('/', auth, async (req, res) => {
  try {
    const { content, issue } = req.body;

    // Basic validation
    if (!content || !issue) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const comment = new Comment({ content, user: req.user.id, issue });
    await comment.save();

    res.status(201).json({
      message: "Comment added",
      comment
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET COMMENTS FOR A SPECIFIC ISSUE
router.get('/:issueId', async (req, res) => {
  try {
    const comments = await Comment.find({ issue: req.params.issueId })
      .populate('user', 'username profile')
      .sort({ createdAt: -1 }); 

    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
