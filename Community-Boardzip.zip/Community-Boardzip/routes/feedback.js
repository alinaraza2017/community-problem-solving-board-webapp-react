const router = require('express').Router();
const Feedback = require('../models/feedback');
const auth = require('../middlewares/authMiddleware').protect; 

router.post('/', async (req, res) => {
  try {
    const { issueId, rating, comment, type } = req.body;

    const feedbackType = type || (issueId ? 'issue' : 'general');

   
    const feedbackData = {
      type: feedbackType,
      rating,
      comment,
      issueId: feedbackType === 'issue' ? issueId : undefined
    };

    if (req.user) {
      feedbackData.user = req.user.id;
    }

    const feedback = new Feedback(feedbackData);
    await feedback.save();

    res.status(201).json({ message: 'Feedback submitted successfully', feedback });
  } catch (err) {
    console.error(err);
    if (err.code === 11000) {
      return res.status(409).json({ message: 'Feedback already exists' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.get('/:issueId', auth, async (req, res) => {
  try {
    const feedback = await Feedback.findOne({
      issueId: req.params.issueId,
      user: req.user.id
    });

    res.json({ feedback });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
