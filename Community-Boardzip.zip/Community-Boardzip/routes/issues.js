const express = require('express');
const router = express.Router();
const validate = require('../middlewares/validate');
const { protect, authorize } = require('../middlewares/authMiddleware');
const {
  createIssue,
  getIssues,
  getIssue,
  getReportedIssues,
  getVotedIssues,
  updateIssue,
  deleteIssue,
  upvoteIssue,
  issueSchema,
  updateIssueSchema
} = require('../controllers/issueController');

router.get('/posted', protect, getReportedIssues);
router.get('/voted', protect, getVotedIssues);

// API Endpoints
router.route('/')
  .post(protect, validate(issueSchema), createIssue)
  .get(getIssues);

router.route('/:id')
  .get(getIssue)
  .put(protect, validate(updateIssueSchema), updateIssue)
  .delete(protect, deleteIssue);

router.put('/upvote/:id', protect, upvoteIssue);

module.exports = router;
