const Issue = require('../models/Issue');
const asyncHandler = require('express-async-handler');
const Joi = require('joi');

// Joi Validation Schemas
const issueSchema = Joi.object({
  title: Joi.string().required(),
  description: Joi.string().required(),
  category: Joi.string().valid('road', 'lighting', 'sanitation', 'other').required(),
  location: Joi.string().allow('', null)
});

const updateIssueSchema = Joi.object({
  title: Joi.string(),
  description: Joi.string(),
  category: Joi.string().valid('road', 'lighting', 'sanitation', 'other'),
  location: Joi.string().allow('', null),
  status: Joi.string().valid('reported', 'in progress', 'resolved')
});


const createIssue = asyncHandler(async (req, res) => {
  const { title, description, category, location } = req.body;

  const issue = await Issue.create({
    title,
    description,
    category,
    location,
    reporter: req.user.id
  });

  res.status(201).json(issue);
});


const getIssues = asyncHandler(async (req, res) => {
  const issues = await Issue.find()
    .populate('reporter', 'username profile')
    .sort({ createdAt: -1 });
  res.json(issues);
});


const getIssue = asyncHandler(async (req, res) => {
  const issue = await Issue.findById(req.params.id)
    .populate('reporter', 'username profile');

  if (!issue) {
    res.status(404);
    throw new Error('Issue not found');
  }

  res.json(issue);
});


const getReportedIssues = asyncHandler(async (req, res) => {
  const issues = await Issue.find({ reporter: req.user.id })
    .sort({ createdAt: -1 });
  res.json(issues);
});


const getVotedIssues = asyncHandler(async (req, res) => {
  const issues = await Issue.find({ voters: req.user.id })
    .sort({ createdAt: -1 });
  res.json(issues);
});


const updateIssue = asyncHandler(async (req, res) => {
  let issue = await Issue.findById(req.params.id);

  if (!issue) {
    res.status(404);
    throw new Error('Issue not found');
  }

  // Ensure user owns the issue or is an admin
  if (issue.reporter.toString() !== req.user.id && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to update this issue');
  }

  issue = await Issue.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(issue);
});


const deleteIssue = asyncHandler(async (req, res) => {
  const issue = await Issue.findById(req.params.id);

  if (!issue) {
    res.status(404);
    throw new Error('Issue not found');
  }

  if (issue.reporter.toString() !== req.user.id && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to delete this issue');
  }

  await Issue.findByIdAndDelete(req.params.id);
  res.json({ message: 'Issue removed' });
});


const upvoteIssue = asyncHandler(async (req, res) => {
  const issue = await Issue.findById(req.params.id);

  if (!issue) {
    res.status(404);
    throw new Error('Issue not found');
  }

  const alreadyVoted = issue.voters.find(
    (r) => r.toString() === req.user.id.toString()
  );

  if (alreadyVoted) {
    res.status(400);
    throw new Error('Already voted');
  }

  issue.voters.push(req.user.id);
  issue.votes += 1;
  await issue.save();

  res.json({ message: 'Upvoted successfully', votes: issue.votes });
});

module.exports = {
  createIssue,
  getIssues,
  getIssue,
  getReportedIssues,
  getVotedIssues,
  updateIssue,
  deleteIssue,
  upvoteIssue,
  issueSchema,
  updateIssueSchema
};
