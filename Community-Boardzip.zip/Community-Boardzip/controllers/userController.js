const User = require('../models/User');
const Issue = require('../models/Issue');
const Comment = require('../models/comment');
const asyncHandler = require('express-async-handler');
const Joi = require('joi');

const updateUserSchema = Joi.object({
  username: Joi.string(),
  email: Joi.string().email(),
  profile: Joi.object({
    name: Joi.string().allow('', null),
    avatar: Joi.string().allow('', null),
    bio: Joi.string().allow('', null),
    location: Joi.string().allow('', null),
    contact: Joi.string().allow('', null)
  })
});


const getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  const issuesReported = await Issue.countDocuments({ reporter: req.user.id });
  const issuesResolved = await Issue.countDocuments({ reporter: req.user.id, status: 'resolved' });
  const commentsCount = await Comment.countDocuments({ user: req.user.id });
  const upvotesGiven = await Issue.countDocuments({ voters: req.user.id });

  const stats = {
    issuesReported,
    issuesResolved,
    commentsCount,
    upvotesGiven,
  };

  if (user.role === 'admin') {
    const totalIssues = await Issue.countDocuments();
    stats.totalCommunityIssues = totalIssues;
  }

  res.json({ user, stats });
});

const getUsers = asyncHandler(async (req, res) => {
  const users = await User.find({}).select('-password');
  res.json(users);
});


const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');

  if (user) {
    res.json(user);
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});


const updateUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  // Ensure user is updating their own profile or is an admin
  if (user._id.toString() !== req.user.id && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('You can only update your own profile');
  }

  if (req.body.username) user.username = req.body.username;
  if (req.body.email) user.email = req.body.email;
  if (req.body.profile) {
      user.profile = { ...user.profile, ...req.body.profile };
  }

  const updatedUser = await user.save();

  res.json({
    message: 'Profile updated successfully',
    user: {
      _id: updatedUser._id,
      username: updatedUser.username,
      email: updatedUser.email,
      role: updatedUser.role,
      profile: updatedUser.profile
    }
  });
});

module.exports = {
  getProfile,
  getUsers,
  getUserById,
  updateUserProfile,
  updateUserSchema
};
